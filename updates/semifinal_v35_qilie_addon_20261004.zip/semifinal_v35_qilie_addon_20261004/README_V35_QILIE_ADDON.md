# V35 气裂（qilie）补类云端包（2026-10-04）

## 这个包做什么

- **不训练、不重新推理、不需要 GPU 算力**（只用 CPU，约几分钟）。
- 直接复用 V7 已核验的 **Model A 全 9 类 TTA 候选缓存**，按与 V7 完全相同的逐模型 NMS 提取第 9 类 **qilie（气裂/横裂）**，用保守阈值过滤后，合并进当前官方保护分 **67.92 的 V12** 提交。
- 逐字保证 V12 原 **165,421 行**的类别、框、分数、顺序完全不变，仅在末尾追加 qilie 行；再以 **9 类口径**重新校验并打包。

## 为什么值得做（收益近非对称）

- 官方竞赛规则第 6 页的 JSON 范例本身包含 `qilie`，任务为 9 类；V12 却完全没有交气裂。
- 若平台按 9 类 macro 平均 AP（V12 当前气裂 AP=0）：补到 AP=0.3 约 **+0.67 分**，AP=0.5 约 **+1.11 分**；若同时找回气裂真值，Recall 每个约 +0.067。
- 若 Test 没有气裂真值：该类不进入 macro，仅多若干 FP，影响约 **−0.0003（≈中性）**。
- 复赛规则为每天 ≤5 次、**取最优成绩**：探针不会拉低 67.92，可放心提交。

## 解压与预检

```bash
cd /mnt/proj
python3 -m zipfile -e semifinal_v35_qilie_addon_20261004.zip /mnt/proj
cd /mnt/proj/semifinal_v35_qilie_addon_20261004

/mnt/proj/iron/.venv/bin/python scripts/run_v35_qilie_addon_pipeline.py --preflight-only
```

预检需显示：788 张 Test 图、找到并核验 Model A TTA 缓存（SHA256 与 V7 一致）、找到 V12 提交。

## 正式运行

```bash
/mnt/proj/iron/.venv/bin/python -u scripts/run_v35_qilie_addon_pipeline.py \
    --project-root /mnt/proj/iron --threshold 0.30
```

常用参数：

- `--threshold`：qilie 保留阈值，默认 **0.30**（宁可少而准）；若首探正向，可再用 0.20 / 0.15 各出一包。
- `--v12`：当自动定位不到 V12 时，显式指定 V12 `submission.json` 或 V12 `SUBMIT_ONLY.zip`。
- `--cache`：显式指定 Model A TTA 缓存（默认在 V7 输出目录自动定位）。

## 产物与提交

```text
/mnt/proj/iron/runs/semifinal/v35_qilie_addon_20261004/semifinal_v35_qilie_addon_SUBMIT_ONLY.zip
```

- 根目录唯一 `submission.json`；`V35_BUILD_REPORT.json` 记录 qilie 数量、9 类校验结果与 SHA256。
- 提交后回报官方 mAP50 / TP / FP / FN：
  - 分数 > 67.92：保留，并降低阈值再探一包；
  - 分数 ≤ 67.92：V12 自动保留，无损失。

## 更快的判定方式

若能打开官方成绩**详情页**，直接看是否列出 `qilie`：

- 有 qilie 且 AP=0 → 平台按 9  macro，务必补（本包即为解法）；
- 详情页只有 8 类 → 平台忽略气裂，无需提交本包。

## 边界声明

本包不接触 Test 标签；所有增益数字为基于评分公式与 V12 官方回传的推算，**不是官方保证**。qilie 训练样本极少（约 28 个框），单模型提取的气裂质量有限，故默认采用高阈值、小步探针。
