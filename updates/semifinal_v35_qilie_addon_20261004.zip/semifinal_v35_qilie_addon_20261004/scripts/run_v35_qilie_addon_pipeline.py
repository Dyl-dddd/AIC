"""V35: build a qilie (9th class) add-on SUBMIT_ONLY package from the verified
Model A TTA cache, merged into the protected V12 submission.

本脚本不训练、不重新推理：直接复用 V7 已核验的 Model A 全 9 类 TTA 候选缓存，
按 V7 完全相同的逐模型 NMS 提取 qilie，保守阈值过滤后合并进 V12，逐字保证
V12 原 165,421 行不变，再以 9 类口径校验并打包。纯 CPU，约几分钟。

用法：
  # 预检（只检查缓存/V12/GPU 信息，不写包）
  python scripts/run_v35_qilie_addon_pipeline.py --preflight-only

  # 正式运行
  python scripts/run_v35_qilie_addon_pipeline.py \
      --project-root /mnt/proj/iron --threshold 0.30
"""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from steel_defect.classes import CLASS_NAMES
from steel_defect.inference import InferenceOptions, merge_candidates


MODEL_A_SHA256 = "d69b236a91599f850b495d7b2e60d87c0c4905713398baca21d18e564cc42a4d"
EXPECTED_IMAGES = 788
V12_ROWS = 165_421

# V7 primary per-model merge policy (must match the cache that fed V12)
PER_MODEL_NMS_IOU = 0.68
EDGE_PENALTY = 0.5
MERGE_CONF = 0.0001

CACHE_CANDIDATES = (
    "runs/semifinal/ensemble_v7_tta_submission/test_model_a_tta_1e5.jsonl.gz",
    "runs/semifinal/final_submission_tta_v1/test_candidates_tta_1e5.jsonl.gz",
)
V12_CANDIDATES = (
    "runs/semifinal/v12_perclass_ranker_20261001/submission/submission.json",
    "runs/semifinal/v12_perclass_ranker_20261001/submission.json",
)
V12_ZIP_GLOBS = (
    "runs/semifinal/**/semifinal_v12_perclass_ranker_SUBMIT_ONLY*.zip",
    "**/semifinal_v12_perclass_ranker_SUBMIT_ONLY*.zip",
)

EXPECTED_CACHE_OPTIONS = {
    "tile_layout": "semifinal_grid",
    "tile_size": 1024,
    "overlap": 0.25,
    "imgsz": 1024,
    "batch": 1,
    "conf": 0.00001,
    "local_iou": 0.70,
    "half": True,
    "tta": True,
    "deblur": False,
    "clahe": False,
    "global_pass": True,
    "max_det": 2000,
}


def sha256_file(path: Path) -> str:
    import hashlib
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_cache(path: Path) -> int:
    count = 0
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        header = json.loads(next(handle))
        if header.get("type") != "candidate_cache_header" or header.get("schema") != 3:
            raise ValueError(f"invalid candidate cache: {path}")
        if header.get("weights_sha256") != MODEL_A_SHA256:
            raise ValueError(f"cache is not Model A: {path}")
        if header.get("classes") != CLASS_NAMES:
            raise ValueError(f"cache classes are not all 9: {path}")
        options = header.get("options", {})
        mismatched = {
            key: {"expected": value, "actual": options.get(key)}
            for key, value in EXPECTED_CACHE_OPTIONS.items()
            if options.get(key) != value
        }
        if mismatched:
            raise ValueError(f"cache policy mismatch: {path}: {mismatched}")
        for line in handle:
            json.loads(line)
            count += 1
    if count != EXPECTED_IMAGES:
        raise ValueError(f"cache has {count} images, expected {EXPECTED_IMAGES}: {path}")
    return count


def locate_cache(project: Path) -> Path:
    for relative in CACHE_CANDIDATES:
        path = project / relative
        if path.is_file():
            validate_cache(path)
            print(f"using verified Model A TTA cache: {path}", flush=True)
            return path
    raise FileNotFoundError(
        "未找到已核验的 Model A TTA 缓存。请先在云端跑通 V7 TTA 推理包以生成缓存，"
        "或用 --cache 显式指定。"
    )


def extract_v12_from_zip(zip_path: Path, workdir: Path) -> Path:
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        target = next((n for n in names if n.endswith("submission.json")), None)
        if target is None:
            raise ValueError(f"{zip_path} 内没有 submission.json")
        data = archive.read(target)
    out = workdir / "v12_submission.json"
    out.write_bytes(data)
    return out


def locate_v12(project: Path, explicit: Path | None, workdir: Path) -> Path:
    if explicit is not None:
        if explicit.suffix == ".zip":
            return extract_v12_from_zip(explicit, workdir)
        return explicit
    for relative in V12_CANDIDATES:
        path = project / relative
        if path.is_file():
            return path
    for pattern in V12_ZIP_GLOBS:
        matches = sorted(project.glob(pattern))
        if matches:
            return extract_v12_from_zip(matches[0], workdir)
    raise FileNotFoundError(
        "未找到 V12 submission.json，也未找到 V12 SUBMIT_ONLY zip；请用 --v12 显式指定。"
    )


def iter_cache_records(path: Path):
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        next(handle)  # header
        for line in handle:
            yield json.loads(line)


def extract_qilie(cache: Path, threshold: float) -> tuple[list[dict], dict]:
    options = InferenceOptions(
        conf=MERGE_CONF, iou=PER_MODEL_NMS_IOU, edge_penalty=EDGE_PENALTY, merge="nms",
    )
    kept: list[dict] = []
    seen: set[tuple[str, tuple[int, ...]]] = set()
    stats = {"images": 0, "raw_qilie_after_nms": 0, "below_threshold": 0,
             "duplicate": 0, "kept": 0, "images_with_qilie": 0}
    for record in iter_cache_records(cache):
        stats["images"] += 1
        merged = merge_candidates(
            record["candidates"], tuple(record["image_size"]), CLASS_NAMES, options
        )
        q = [item for item in merged if item["category_name"] == "qilie"]
        stats["raw_qilie_after_nms"] += len(q)
        if q:
            stats["images_with_qilie"] += 1
        for item in q:
            if float(item["score"]) < threshold:
                stats["below_threshold"] += 1
                continue
            image_id = Path(record["image_id"]).name
            key = (image_id, tuple(item["bbox"]))
            if key in seen:
                stats["duplicate"] += 1
                continue
            seen.add(key)
            kept.append({
                "image_id": image_id,
                "category_name": "qilie",
                "bbox": item["bbox"],
                "score": item["score"],
            })
    stats["kept"] = len(kept)
    return kept, stats


def merge_and_validate(v12: list[dict], qilie: list[dict]) -> list[dict]:
    if len(v12) != V12_ROWS:
        raise ValueError(f"V12 行数 {len(v12)} != {V12_ROWS}，请确认基线版本")
    if any(r["category_name"] == "qilie" for r in v12):
        raise ValueError("V12 基线里已存在 qilie，不应重复合并")
    merged = v12 + qilie
    for index, original in enumerate(v12):
        if merged[index] != original:
            raise ValueError(f"第 {index} 行 V12 原记录被改动，中止")
    return merged


def package(staging_json: Path, out_zip: Path) -> str:
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        archive.write(staging_json, arcname="submission.json")
    return sha256_file(out_zip)


def run(project: Path, source: Path, v12_arg: Path | None, cache_arg: Path | None,
        threshold: float, out_dir: Path) -> dict:
    cache = cache_arg or locate_cache(project)
    if cache_arg:
        validate_cache(cache)
    with tempfile.TemporaryDirectory() as tmp:
        workdir = Path(tmp)
        v12_path = locate_v12(project, v12_arg, workdir)
        v12 = json.loads(v12_path.read_text(encoding="utf-8"))
        qilie, qstats = extract_qilie(cache, threshold)
        if not qilie:
            raise SystemExit("阈值过滤后没有 qilie 框，请降低 --threshold 或检查缓存，中止")
        merged = merge_and_validate(v12, qilie)

        staging = workdir / "submission.json"
        staging.write_text(json.dumps(merged, ensure_ascii=False), encoding="utf-8")

        # 9-class validation (do NOT exclude qilie)
        validation_path = out_dir / "validation.json"
        out_dir.mkdir(parents=True, exist_ok=True)
        import subprocess
        subprocess.run(
            [sys.executable, "-u", str(ROOT / "scripts/validate_large_submission.py"),
             str(staging), "--source", str(source), "--report", str(validation_path)],
            check=True,
        )
        validation = json.loads(validation_path.read_text(encoding="utf-8"))

        out_zip = out_dir / "semifinal_v35_qilie_addon_SUBMIT_ONLY.zip"
        zip_sha = package(staging, out_zip)
        # copy the validated submission next to the zip for inspection
        (out_dir / "submission.json").write_bytes(staging.read_bytes())

    report = {
        "project_root": str(project),
        "cache": str(cache),
        "cache_sha256": sha256_file(cache),
        "v12_path": str(v12_path),
        "v12_rows": len(v12),
        "threshold": threshold,
        "qilie_stats": qstats,
        "total_rows": len(merged),
        "validation": validation,
        "submit_zip": str(out_zip),
        "submit_zip_sha256": zip_sha,
        "note": "复赛取最优成绩，探针不影响 V12 保护分 67.92",
    }
    (out_dir / "V35_BUILD_REPORT.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path("/mnt/proj/iron"))
    parser.add_argument("--source", type=Path, default=None)
    parser.add_argument("--v12", type=Path, default=None, help="V12 submission.json 或 SUBMIT_ONLY zip")
    parser.add_argument("--cache", type=Path, default=None, help="Model A TTA 缓存（默认自动定位）")
    parser.add_argument("--threshold", type=float, default=0.30)
    parser.add_argument("--out-dir", type=Path, default=None)
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()

    project = args.project_root.resolve()
    source = (args.source or project / "data/semifinal/test").resolve()
    out_dir = args.out_dir or project / "runs/semifinal/v35_qilie_addon_20261004"

    cache = args.cache or locate_cache(project)
    if args.cache:
        validate_cache(cache)
    with tempfile.TemporaryDirectory() as tmp:
        v12_path = locate_v12(project, args.v12, Path(tmp))
    images = {p.name for p in source.rglob("*")
              if p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}}
    preflight = {
        "project_root": str(project),
        "source": str(source),
        "test_images": len(images),
        "cache": str(cache),
        "cache_sha256": sha256_file(cache),
        "v12": str(v12_path),
        "threshold": args.threshold,
        "training": False,
    }
    print(json.dumps(preflight, ensure_ascii=False, indent=2), flush=True)
    if args.preflight_only:
        return
    run(project, source, args.v12, args.cache, args.threshold, out_dir)


if __name__ == "__main__":
    main()
