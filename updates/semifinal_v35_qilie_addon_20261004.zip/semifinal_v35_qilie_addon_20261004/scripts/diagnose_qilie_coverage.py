"""Diagnostic: does the Model A TTA cache contain ANY qilie candidate near the
rulebook example qilie location (image 0001417541-Raw02-f_00009.jpg, ~x1084 y2243)?

纯读取缓存、不写任何提交。用于判断"降低阈值"能否救回规则范例所示的气裂。

用法：
  /mnt/proj/iron/.venv/bin/python scripts/diagnose_qilie_coverage.py \
      --cache /mnt/proj/iron/runs/semifinal/final_submission_tta_v1/test_candidates_tta_1e5.jsonl.gz
"""
from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from steel_defect.classes import CLASS_NAMES

QIDX = CLASS_NAMES.index("qilie")

TARGET_IMAGE = "0001417541-Raw02-f_00009.jpg"
TARGET_X, TARGET_Y, RADIUS = 1084, 2243, 300


def center(box):
    return (box[0] + box[2]) / 2, (box[1] + box[3]) / 2


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--image", default=TARGET_IMAGE)
    parser.add_argument("--x", type=int, default=TARGET_X)
    parser.add_argument("--y", type=int, default=TARGET_Y)
    parser.add_argument("--radius", type=int, default=RADIUS)
    args = parser.parse_args()

    found_record = None
    with gzip.open(args.cache, "rt", encoding="utf-8") as handle:
        next(handle)
        for line in handle:
            record = json.loads(line)
            if Path(record["image_id"]).name == args.image:
                found_record = record
                break
    if found_record is None:
        raise SystemExit(f"cache 中找不到 {args.image}")

    q = [c for c in found_record["candidates"] if c["class_id"] == QIDX]
    q.sort(key=lambda c: -float(c["score"]))
    print(f"image={args.image} raw qilie candidates={len(q)}")
    print(f"target=({args.x},{args.y}) radius={args.radius}")

    near = []
    print("\n-- top 25 qilie by raw score --")
    for c in q[:25]:
        cx, cy = center(c["bbox"])
        dist = ((cx - args.x) ** 2 + (cy - args.y) ** 2) ** 0.5
        contains = (c["bbox"][0] <= args.x <= c["bbox"][2] and c["bbox"][1] <= args.y <= c["bbox"][3])
        mark = "NEAR" if dist <= args.radius else ("CONTAINS" if contains else "")
        if dist <= args.radius or contains:
            near.append(c)
        print(f"score={float(c['score']):.4f} bbox={c['bbox']} center=({cx:.0f},{cy:.0f}) dist={dist:.0f} {mark}")

    print("\n-- ALL qilie candidates within/around target --")
    for c in near:
        print(f"score={float(c['score']):.4f} bbox={c['bbox']}")
    if near:
        print(f"\nmin score among target-covering candidates = {min(float(c['score']) for c in near):.4f}")
        print("=> 降低阈值到该水平，有望覆盖规则范例所示气裂。")
    else:
        print("\n没有任何 qilie 候选靠近目标点：Model A 未在此处产生气裂框，降阈值无效，需更好的检测器。")


if __name__ == "__main__":
    main()
